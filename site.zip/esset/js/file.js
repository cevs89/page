var footer;
footer = '    <footer class="page-footer grey darken-4">
      <div class="container">
        <div class="row">
          <div class="col l6 s12">
            <h5 class="white-text">Informacion</h5>
            <p class="grey-text text-lighten-4">Esta pagina esta desarrollada con <span class="">HTML5</span>, CSS3, JavaScript, Materialize y Bower y esta el Github</p>
            <p class="grey-text text-lighten-4 center">Por ahora no usamos galletas <i class="material-icons tiny">thumb_up</i></p>
          </div>
          <div class="col l4 offset-l2 s12">
            <h5 class="white-text">¡Donde encontrarme!</h5>
            <ul class="white-text">
              <li>Caracas, Venezuela</li>
              <li>+58 130 6485</li>
              <li>cevsinformatica@gmail.com</li>
              <li>O mejor</li>
              <li>dale a ese boton <i class="fa fa-arrow-right"></i></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-copyright grey darken-3">
        <div class="container">
        © 2017 Copyright Carlos Velazquez
        <a class="grey-text text-lighten-4 right" href="#!">Quiza puedas ir arriba <i class="fa fa-chevron-up"></i></a>
        </div>
      </div>
    </footer>';
